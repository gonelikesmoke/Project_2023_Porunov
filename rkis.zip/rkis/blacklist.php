<?php
session_start();

if (!isset($_SESSION['user_id'])) {
}

require_once('php/config.php'); 

$sql = "SELECT * FROM users WHERE blacklist = 1";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$search_query = "";
if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];

    if (!empty($search_query)) {
        $sql = "SELECT * FROM users WHERE blacklist = 1 AND firstname LIKE :search_query OR surname LIKE :search_query OR patronymic LIKE :search_query OR email LIKE :search_query OR date LIKE :search_query";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':search_query', "%$search_query%", PDO::PARAM_STR);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Чёрный список</title>
</head>
<body>
    <header class="shadow mb-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-center py-3 mb-4">
                <a href="profile.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                    <span class="fs-4 me-2">Личный кабинет</span>
                </a>
            
                <ul class="nav nav-pills">
                    <?php
                    if (!isset($_SESSION['user_id']))
                    {
                        echo '<li class="nav-item"><a href="login.php" class="nav-link text-body-secondary me-2">Вход</a></li>';
                        echo '<li class="nav-item"><a href="register.php" class="nav-link text-body-secondary">Регистрация</a></li>';
                    }
                    else {
                        echo '<li class="nav-item"><a href="userlist.php" class="nav-link text-body-secondary me-2">Список клиентов</a></li>';
                        echo '<li class="nav-item"><a href="blacklist.php" class="nav-link text-body-secondary me-2">Черный список</a></li>';
                        echo '<li class="nav-item"><a href="php/exit.php" class="nav-link text-body-secondary">Выход</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </header>
    <main>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb fs-5">
                <li class="breadcrumb-item"><a class="text-decoration-none text-dark" href="profile.php">Личный кабинет</a></li>
                <li class="breadcrumb-item active" aria-current="page">Чёрный список</li>
            </ol>
        </nav>
    </div>
    <div class="">
        <form class="container" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="row">
                <div class="col-12 col-lg-4 mb-3">
                    <div class="input-group">
                        <input class="form-control shadow" name="search_query" type="search" placeholder="Поиск..." aria-label="Search">
                    </div>
                </div>
                <div class="col-12 col-lg-2 mb-3">
                    <div class="input-group">
                        <input class="btn btn-dark form-control shadow" name="search" type="submit" aria-label="Search" value="Найти">
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="container card shadow card-body table-responsive">
        <table class="table text-center">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Фамилия</th>
            <th scope="col">Имя</th>
            <th scope="col">Отчество</th>
            <th scope="col">Email</th>
            <th scope="col">Роль</th>
            <th scope="col">Дата регистрации</th>
            <th colspan="2" scope="col">Действия</th>
            </tr>
        </thead>
        <tbody>

        <?php 
            if (count($users) > 0) {
            foreach ($users as $row) {
                ?>
                <tr>
                <th scope="row"><?php echo $row["id"]; ?></th>
                <td><?php echo $row["surname"]; ?></td>
                <td><?php echo $row["firstname"]; ?></td>
                <td><?php echo $row["patronymic"]; ?></td>
                <td><?php echo $row["email"]; ?></td>
                <td><?php echo $row["role"]; ?></td>
                <td><?php echo $row["date"]; ?></td>
                <td>
                    <div class="">
                        <a class="btn btn-success shadow form-control" href="actions/blacklist.php?id=<?php echo $row["id"]; ?>" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Удалить</a>
                    </div>
                </td>
                </tr>
                <?php
            }
            } else {
            ?>
            <tr>
                <td colspan="8">Записей не найдено.</td>
            </tr>
            <?php
            }
        ?>
        </tbody>
        </table>
</div>
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Удаение клиента из чёрного списка</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Вы действительно хотите удалить клиента из чёрного списка?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary form-control" data-bs-dismiss="modal">Отмена</button>
                <a type="button" class="btn btn-success form-control" href="actions/blacklist-remove.php?id=<?php echo $row["id"]; ?>">Удалить</a>
            </div>
            </div>
        </div>
        </div>

    </main>
    
    <footer class="shadow mt-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
                <p class="col-md-4 mb-0 text-body-secondary">Илья Порунов</p>
            
                <ul class="nav col-md-4 justify-content-end">
                    <li class="nav-item"><a href="userlist.php" class="nav-link px-2 text-body-secondary">Список пользователей</a></li>
                    <li class="nav-item"><a href="blacklist.php" class="nav-link px-2 text-body-secondary">Черный список</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>