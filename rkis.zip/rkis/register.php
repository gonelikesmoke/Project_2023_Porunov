<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="mycss/login.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Регистрация</title>
</head>
<body>
    <header class="shadow mb-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-center py-3 mb-4">
                <a href="../" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                    <span class="fs-4 me-2">Главная</span>
                </a>
            
                <ul class="nav nav-pills">
                <?php
                    if (!isset($_SESSION['user_id']))
                    {
                        echo '<li class="nav-item"><a href="login.php" class="nav-link text-body-secondary me-2">Вход</a></li>';
                        echo '<li class="nav-item"><a href="register.php" class="nav-link text-body-secondary">Регистрация</a></li>';
                    }
                    else {
                        echo '<li class="nav-item"><a href="userlist.php" class="nav-link text-body-secondary me-2">Список клиентов</a></li>';
                        echo '<li class="nav-item"><a href="blacklist.php" class="nav-link text-body-secondary me-2">Черный список</a></li>';
                        echo '<li class="nav-item"><a href="php/exit.php" class="nav-link text-body-secondary">Выход</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </header>
    <main>
        <div class="container">
            <section class="py-5 row justify-content-center">
                <form class="col-lg-3" method="post" action="php/register.php">
                    <h1 class="h2 mb-3 fw-normal">Регистрация</h1>
                    <div class="form-floating mb-3">
                    <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                    <label for="floatingInput">Email</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="surname" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Фамилия</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="firstname" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Имя</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input id="inputPatronymic" name="patronymic" type="text" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Отчество</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" name="patronymic" type="checkbox" value="" id="noPatronymicCheckBox">
                        <label class="form-check-label" for="flexCheckDefault">
                        Нет отчества
                        </label>
                    </div>
                    <div class="form-floating mb-3">
                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Пароль</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" name="repeatpassword" class="form-control" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Повтор пароля</label>
                    </div>
                    <input class="btn btn-primary w-100 py-2 mb-3" type="submit" value="Зарегистрироваться" data-bs-toggle="modal" data-bs-target="#exampleModal">
                </form>
            </section>
        </div>
        
    </main>
    
    <footer class="shadow mt-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
                <p class="col-md-4 mb-0 text-body-secondary">Илья Порунов</p>
            
                <ul class="nav col-md-4 justify-content-end">
                    <li class="nav-item"><a href="login.php" class="nav-link px-2 text-body-secondary">Вход</a></li>
                    <li class="nav-item"><a href="register.php" class="nav-link px-2 text-body-secondary">Регистрация</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <script>
        const input = document.getElementById('inputPatronymic'),
            checkbox = document.getElementById('noPatronymicCheckBox');
        checkbox.onchange = function() {
            input.disabled = checkbox.checked;
        }

      </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>