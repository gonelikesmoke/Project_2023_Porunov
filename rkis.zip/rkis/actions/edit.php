<?php
session_start();

require_once('../php/config.php');

$_SESSION['user_id'] = $_GET['id'];
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (isset($_POST['update'])) {
    $surname = $_POST['surname'];
    $firstname = $_POST['firstname'];
    $patronymic = $_POST['patronymic'];
    $role = $_POST['role'];
    $email = $_POST['email'];

    $sql = "UPDATE users SET firstname = :firstname, surname = :surname, patronymic = :patronymic, role = :role, email = :email WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':surname', $surname, PDO::PARAM_STR);
    $stmt->bindValue(':firstname', $firstname, PDO::PARAM_STR);
    $stmt->bindValue(':patronymic', $patronymic, PDO::PARAM_STR);
    $stmt->bindValue(':role', $role, PDO::PARAM_STR);
    $stmt->bindValue(':id', $user_id, PDO::PARAM_INT);
    $stmt->bindValue(':email', $email, PDO::PARAM_STR);
    $stmt->execute();

    header("Location: ../userlist.php");
    exit;
}