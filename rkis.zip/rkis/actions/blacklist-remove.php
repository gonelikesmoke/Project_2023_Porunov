<?php
require_once('../php/config.php'); 


if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $sql = "UPDATE users SET blacklist = 0 WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $userId, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: ../blacklist.php");
    exit;
} else {
    echo "Ошибка: ID пользователя не указан.";
}

$conn = null;
?>