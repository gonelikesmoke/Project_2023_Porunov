<?php
require_once('../php/config.php');

if (isset($_GET['id'])) {
    $userId = $_GET['id'];

    $sql = "DELETE FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $userId, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: ../userlist.php");
    exit;
} else {
    echo "Ошибка: ID пользователя не указан.";
}

$conn = null;
?>