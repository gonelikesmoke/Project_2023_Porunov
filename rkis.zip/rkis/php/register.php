<?php 
require_once('config.php');

$email = $_POST['email'];
$firstname = $_POST['firstname'];
$surname = $_POST['surname'];
$patronymic = $_POST['patronymic'];
$date = date('Y-m-d');
$password = $_POST['password']; 
$repeatpassword = $_POST['repeatpassword'];

if ($password != $repeatpassword) { 
    echo "Пароли не совпадают"; 
} else { 
    $password = password_hash($password, PASSWORD_BCRYPT);
    
    $sql = "INSERT INTO users (email, firstname, surname, patronymic, date, password) VALUES (:email, :firstname, :surname, :patronymic, :date, :password)";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':firstname', $firstname);
        $stmt->bindParam(':surname', $surname);
        $stmt->bindParam(':patronymic', $patronymic);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':password', $password);
        
        if ($stmt->execute()) { 
            echo "Успешная регистрация";
            header("Location: ../index.php");
        } else { 
            echo "Ошибка при регистрации"; 
        }
    } catch (PDOException $e) {
        echo "Ошибка: " . $e->getMessage();
    }
}
?>