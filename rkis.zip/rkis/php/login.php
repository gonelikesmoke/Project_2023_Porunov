<?php
session_start();
require_once('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email AND blacklist = 0");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if ($user) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $userId = $_SESSION['user_id'];
            $sql = "SELECT * FROM users WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            echo $user['role'];
            if ($user['role'] == 'admin') {
                header("Location: ../profile.php");
            } else {
                header("Location: ../profile-manager.php");
                exit(); 
            }
        } else {
            echo "Неправильный пароль.";
        }
    } else {
        echo "Пользователь с таким email не найден.";
    }
}
?>