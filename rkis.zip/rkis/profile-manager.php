<?php
session_start();

if (!isset($_SESSION['user_id'])) {
}

require_once('php/config.php');

$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $userId, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Личный кабинет</title>
</head>
<body>
    <header class="shadow mb-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-center py-3 mb-4">
                <a href="profile-manager.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                    <span class="fs-4 me-2">Личный кабинет</span>
                </a>
            
                <ul class="nav nav-pills">
                    <?php
                    if (!isset($_SESSION['user_id']))
                    {
                        echo '<li class="nav-item"><a href="login.php" class="nav-link text-body-secondary me-2">Вход</a></li>';
                        echo '<li class="nav-item"><a href="register.php" class="nav-link text-body-secondary">Регистрация</a></li>';
                    }
                    else {
                        echo '<li class="nav-item"><a href="userlist-manager.php" class="nav-link text-body-secondary me-2">Список клиентов</a></li>';
                        echo '<li class="nav-item"><a href="blacklist-manager.php" class="nav-link text-body-secondary me-2">Черный список</a></li>';
                        echo '<li class="nav-item"><a href="php/exit.php" class="nav-link text-body-secondary">Выход</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </header>
    <main>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb fs-5">
                <li class="breadcrumb-item active"><a class="text-decoration-none text-dark" href="profile.php" aria-current="page">Личный кабинет</a></li>
            </ol>
        </nav>
    </div>
    </main>
    
    <footer class="shadow mt-auto">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
                <p class="col-md-4 mb-0 text-body-secondary">Илья Порунов</p>
            
                <ul class="nav col-md-4 justify-content-end">
                    <li class="nav-item"><a href="userlist.php" class="nav-link px-2 text-body-secondary">Список пользователей</a></li>
                    <li class="nav-item"><a href="blacklist.php" class="nav-link px-2 text-body-secondary">Черный список</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>